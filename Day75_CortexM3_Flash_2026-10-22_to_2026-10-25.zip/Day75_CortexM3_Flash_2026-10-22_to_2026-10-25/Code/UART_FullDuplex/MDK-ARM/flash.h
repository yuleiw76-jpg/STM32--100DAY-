#ifndef FLASH_H
#define FLASH_H

#include "main.h"

#define STM32_FLASH_SIZE    0x10000
#define STM32_FLASH_BASE    0x08000000
#define DATA_SAVE_BASE      STM32_FLASH_BASE+STM32_FLASH_SIZE-1024


void erase_data_save_flash(void);
#endif
