#include "flash.h"

extern float PID_P ;

void erase_data_save_flash()
{
   HAL_FLASH_Unlock();
	
	FLASH_EraseInitTypeDef eraseConfig;
	
	uint32_t pageError ;
	
	//uint32_t PageNumber = (DATA_SAVE_BASE - FLASH_BASE)/ FLASH_PAGE_SIZE ;
	
	eraseConfig.TypeErase = FLASH_TYPEERASE_PAGES ;
	eraseConfig.PageAddress = DATA_SAVE_BASE ;
	eraseConfig.NbPages = 1 ;
	
	HAL_FLASHEx_Erase(&eraseConfig,&pageError);
	uint32_t data =*(uint32_t*)&PID_P;
	
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,DATA_SAVE_BASE+4,data);
	
	HAL_FLASH_Lock();
}
