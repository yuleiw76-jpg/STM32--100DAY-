/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
#define RX_DATA_LEN (5+4)

uint8_t rx_buffer[RX_DATA_LEN] ;
volatile uint8_t wave = 0 ;
volatile float wave2 = 0.0f;
volatile uint8_t tx_busy = 0 ;
uint8_t tx_buffer[TX_DATA_LEN];

/* USER CODE END 0 */

UART_HandleTypeDef huart1;

/* USART1 init function */

void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
tx_buffer[0]= 0xAA;
tx_buffer[1]= 0x55;
tx_buffer[2]= TX_DATA_LEN - 4;	
HAL_UART_Receive_IT(&huart1,rx_buffer,RX_DATA_LEN);
  /* USER CODE END USART1_Init 2 */

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */
    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* USART1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
void ProcessData(uint8_t *rx_buf)
{
  if(rx_buf[0]!= 0XAA || rx_buf[1]!= 0X55) return ;
  if(rx_buf[2]!= RX_DATA_LEN-4) return ;	
	uint8_t checksum =0 ;
	for(int i=0 ; i< 3+rx_buf[2] ; i++){
	   checksum += rx_buf[i] ;
	}
	if(checksum!= rx_buf[3+rx_buf[2]]) return ; //bi jiao yao fang zai quan bu jia wan yi hou . 
	FloatConverter converter ;
	for(int i=0 ;i< 4 ; i++){ // i< x , x gen'ju shu'ju'zhen de xia'jiao'biao' ding 
	  converter.bytes[i] = rx_buf[3+1+i] ; 
	}
	wave = rx_buf[3];
	wave2 = converter.f_val ;
	//if(rx_buf[0]== 0XAA && rx_buf[1]== 0X55){
	  // wave = rx_buf[2] ;
	//}
	
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
   if(huart-> Instance == USART1){
	   ProcessData(rx_buffer) ;
		 HAL_UART_Receive_IT(&huart1, rx_buffer, RX_DATA_LEN);
	 }
}
void UART_Send(uint8_t *data, uint16_t size)
{
   while(tx_busy != 0)
	 {
	    }
	 tx_busy = 1 ;
	 if(HAL_UART_Transmit_IT(&huart1,data,size)!= HAL_OK){
	    tx_busy = 0 ;
		 Error_Handler() ;
	 }

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  if(huart->Instance == USART1){
	   tx_busy =  0 ;
	}
}
/* USER CODE END 1 */
