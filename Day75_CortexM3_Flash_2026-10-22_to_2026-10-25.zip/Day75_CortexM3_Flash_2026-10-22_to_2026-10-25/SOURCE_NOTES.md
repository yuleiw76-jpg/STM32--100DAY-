# 源码归档说明

## 原件与副本

原活动工程：`C:/Users/YueWang/Desktop/hal1/UART_FullDuplex`。
副本：[Code/UART_FullDuplex](Code/UART_FullDuplex)。

本次复制 189 份文件，总计 17,220,173 字节。保留原目录布局，逐项以尺寸和 SHA256 核对；结果见 [SOURCE_MANIFEST.json](SOURCE_MANIFEST.json)。
这些哈希记录的是归档时的原件，不代表未来活动工程仍保持同样内容。

代码由用户按原手册编写、接入和验证。助手只做归档副本与只读核查，没有在此副本或活动源码里添加新功能。此前回退的助手扩展版不在 Code 目录中。

## 打开工程

入口：[UART_FullDuplex.uvprojx](Code/UART_FullDuplex/MDK-ARM/UART_FullDuplex.uvprojx)。

已包含 Core、所需 HAL/CMSIS 头文件及驱动、启动文件、RTE 配置、CubeMX .ioc 和用户 flash.c/h；21 个工程 FilePath 与 6 个 IncludePath 均可在副本内解析。ST/CMSIS 许可文本随源码保留。

原环境：Keil µVision 5.29、ARMCC 5.06 update 6（build 750）、Keil.STM32F1xx_DFP 2.2.0、STM32Cube FW_F1 V1.8.7。Keil 本机工具和外部器件 Pack 不包含在本包中，打开工程的电脑需具备相应开发环境。

MCU 为 STM32F103C8T6；`STM32F103xB` 是该 HAL 工程使用的中容量系列定义。生效 ROM 配置从 0x08000000 起，长度 0xFC00；最后 1KiB 用于参数。

## 这是最终读取验证版

归档时 `PID_P` 初值为 0.77，`erase_data_save_flash();` 已注释；随后先清零，再从 `DATA_SAVE_BASE+4` 读取。它依赖参数页里已有写入记录，不会在空白芯片上自动建立默认参数。

要复现今天的完整手册实验，由使用者先按手册运行写入阶段（工作值设为 3.77，并调用保存），再恢复此读取验证阶段。不要在每次启动时无条件保存默认值。下载工具若整片擦除，也会清掉参数页；本次下载后的读回成功不等于所有下载设置都能保留参数。

没有另外制作写入阶段的源码快照，避免把整理者重建的文件误当作当时原件。

## 有意排除的本机文件

不包含编译输出目录、AXF/HEX/对象文件、原始 build_log、JLink 日志与设置、.uvoptx、.uvguix 或工具许可信息。没有复制此前助手扩展版 flash_param.c/h。

原源码未因归档而调整：教材中的 HAL 状态检查缺失、float 指针重解释、宏括号等改进点均在 README 中说明。收尾不会替用户改写这些内容。
