# 2026-10-25 编译摘要（已有日志摘录）

本文件摘录用户实验后已有的 Keil 日志与 map，不是助手重新执行编译所得。原始 HTML 日志含本机许可信息，因此不放入上传包。

| 项目 | 原记录 |
| --- | --- |
| 工程 | UART_FullDuplex.uvprojx |
| 原日志位置（相对原工程） | MDK-ARM/UART_FullDuplex/UART_FullDuplex.build_log.htm |
| 日志文件修改时间（本地） | 2026-10-25 21:08:49 |
| IDE | Keil µVision 5.29 |
| 编译器 | ARMCC 5.06 update 6，build 750 |
| 构建结果 | 0 Error(s), 0 Warning(s) |
| Code | 6440 字节 |
| RO-data | 312 字节 |
| RW-data | 40 字节 |
| ZI-data | 1720 字节 |
| ROM 占用（Code + RO + RW） | 6792 字节，约 6.63KiB |
| map 中 Load Region 起点 | 0x08000000 |
| map 中 Load Region 大小 | 0x1A88 |
| map 中 Load Region 最大长度 | 0xFC00 |
| map 中 PID_P 运行地址 | 0x20000000 |

生效 ROM 区域长度为 0xFC00；器件通用 IROM 元数据仍可能列出物理容量 0x10000，不能把该元数据当成生效链接长度。

以上是构建与布局证据。实物读写与掉电验证见 [截图说明](README.md)，不能只凭编译通过推断硬件实验成功。
