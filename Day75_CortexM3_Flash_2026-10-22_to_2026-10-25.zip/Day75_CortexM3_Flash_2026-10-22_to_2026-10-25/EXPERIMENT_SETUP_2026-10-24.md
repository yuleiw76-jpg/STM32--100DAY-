# 2026-10-24｜Flash 最小实验接入记录

**历史记录，后续推进已停止。** 正文已由用户确认全部读完；用户完成 IROM1 Size `0xFC00` 配置和基线编译。Codex 随后把“全部给我吧，时间不多了”延伸理解为直接修改工程，加入了不同于原手册的实现。用户已指出这不符合学习意图，要求停止，并决定明天自己按手册重新写。

下列实现及编译事实仅作过程记录，不作为用户独立成果，也不是明天默认采用的方案。最新安排以 [当日收尾](README_2026-10-24.md) 为准；今晚不修改或恢复工程。

## 交付位置

- [操作说明](C:/Users/YueWang/Desktop/hal1/UART_FullDuplex/FLASH_EXPERIMENT_README_2026-10-24.md)
- [工程](C:/Users/YueWang/Desktop/hal1/UART_FullDuplex/MDK-ARM/UART_FullDuplex.uvprojx)
- [Flash 接口](C:/Users/YueWang/Desktop/hal1/UART_FullDuplex/Core/Inc/flash_param.h)
- [Flash 实现](C:/Users/YueWang/Desktop/hal1/UART_FullDuplex/Core/Src/flash_param.c)
- [主程序接入](C:/Users/YueWang/Desktop/hal1/UART_FullDuplex/Core/Src/main.c)
- [本次最终构建日志](C:/Users/YueWang/Desktop/stm32-codex-text/Build_Logs/Flash_Experiment_2026-10-24_build.txt)

修改前备份：`C:/Users/YueWang/Desktop/stm32-codex-text/Backups/Flash_Experiment_2026-10-24_before_codex_223732`，含 main.c、uvprojx、uvoptx。用户已完成的 `0xFC00` 设置包含在此备份中。

## 实际核验

- 本机 Keil ARMCC 5.06 update 6 实际编译：**0 错误、0 警告**，生成 AXF/HEX。
- Code=5908、RO-data=312、RW-data=76、ZI-data=1748 字节；map 总 ROM 为 6296 字节。
- map 中 LR_IROM1 起点 `0x08000000`，最大长度 `0xFC00`；当前映像长度 `0x1898`。参数页 `0x0800FC00–0x0800FFFF` 未放入程序链接区域。
- 新源文件已登记，主函数 USER CODE 区之外的原始内容与备份一致。原串口协议及收发逻辑保留，发送内容改为 PID_P，以观察断电后恢复的数值。
- 独立只读审查未发现阻断问题；不是硬件验证。

## 实现范围

仅存一个 float PID_P；开机只读有效记录，否则保持默认 0.77f。Watch 的 flash_save_request=1 触发一次保存，flash_read_request=1 触发仅读取。使用 memcpy 保留浮点位表示，记录有效标记与反码校验；每步检查 HAL 状态，完成后重新上锁并逐位读回核对。单页中断掉电不保证保留旧参数，未扩展双页恢复或多个 PID 参数。

## 曾提出的验收步骤（已停止推进）

1. 将 PID_P 改为 3.77，触发一次保存；观察 HAL_OK、有效记录、保存次数和读回值。
2. 将 RAM 中 PID_P 改为 0，触发仅读取；预期恢复约 3.77，保存次数不增加。
3. 真正断电重启，无需修改代码或重新下载；通过原串口上位机观察是否恢复约 3.77。

上述步骤未取得用户实测证据，现不再作为接续要求。用户已决定自己重写，后续实现与验证由用户主导，助手不主动带写或操作工程。本文件保留历史，不分配新的 GitHub Day，不提交或上传。
