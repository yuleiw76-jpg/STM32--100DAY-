# 2026-10-20｜最终构建脱敏摘要

这是读取用户已有日志所得摘要，不是Codex再次构建。

| 字段 | 记录 |
| --- | --- |
| 工程/Target | UART_FullDuplex |
| 原日志最后修改时间 | 2026-10-20 22:27:48，本机文件时间 |
| 编译器 | Arm Compiler V5.06 update 6 build750 |
| 编译与链接 | 日志包含main.c、usart.c编译与链接 |
| 结果 | 0 Error(s), 0 Warning(s) |
| Program Size | Code=4824；RO-data=312；RW-data=32；ZI-data=1720 |
| 输出 | 日志记录创建hex；本包不含hex/axf |
| 库/设备环境 | STM32Cube FW_F1 V1.8.7；设备STM32F103C8；本地日志列出CMSIS5.6.0、STM32F1xx_DFP2.2.0 |

类型名最终统一为FloatConverter。早一版曾因floatConverter/FloatConverter不一致报1错误，不能把早一版日志当成最终成功证明。

未复制原始build_log.htm、J-Link日志、下载器设置、uvoptx或uvguix，以避免附带许可证及个人配置。摘要不证明归档副本已在另一台机器构建，也不提供已下载固件与源码的二进制身份认证。
