#include "led.h"
#include "delay.h"
#include "sys.h"
#include "dac.h"


 int main(void)
 {	

	delay_init();	  	  
	LED_Init();	
	dac_Init();	 	 
	dac_Set_Vol(1.65);
	while(1)   
	{
		delay_ms(100);						
	}
 }

