# 用户提供 DAC 工程的静态核对

核对日期：2026-10-21。来源为用户提供的教材代码目录 `9.DAC`。本包仅复制和说明原始文件，未修改其实现、目标配置或文本编码。

## 实际源码与课堂内容

| 文件 | 已核对行为 |
| --- | --- |
| [main.c](Code/DAC_Original/USER/main.c) | delay、LED、DAC 初始化后调用 dac_Set_Vol(1.65)，循环只延时 100 ms |
| [dac.c](Code/DAC_Original/HARDWARE/DAC/dac.c) | 开 GPIOA/DAC 时钟，PA4 模拟模式，关闭触发/内部波形，关闭 DAC 输出缓冲，启用通道 1，初始写 0 |
| [dac.h](Code/DAC_Original/HARDWARE/DAC/dac.h) | 声明 dac_Init 与 dac_Set_Vol |
| [stm32f10x_dac.c](Code/DAC_Original/STM32F10x_FWLib/src/stm32f10x_dac.c) | 保留原标准库实现，供阅读接口与寄存器写入流程 |
| [README.TXT](Code/DAC_Original/README.TXT) | 原 GPIO/LED 模板说明，含原有来源署名；不能作为 DAC 验收记录 |

源文件中文注释经 GBK 解码可正常读取，复制保持原字节。若编辑器默认 UTF-8 显示乱码，应先选择合适编码查看，不为修复显示而直接覆盖原文件。

## Keil 项目配置

| 项目项 | 当前保存值 |
| --- | --- |
| 入口 | Code/DAC_Original/USER/LED.uvprojx |
| 目标 | STM32F103C8 |
| 宏 | STM32F10X_MD、USE_STDPERIPH_DRIVER |
| 工程内存范围 | Flash 0x10000（64 KiB）、RAM 0x5000（20 KiB） |
| 编译器记录 | ARMCC V5.06 update 6，build 750 |
| 工程实际引用启动文件 | CORE/startup_stm32f10x_hd.s |
| 输出目录 | ../OBJ/，历史产物未打包 |

这里存在“C8/MD/HD/DAC”不一致：不能通过仅更改一个名称来证明适配成功。后续应按实际芯片核对器件、内存、库宏、启动文件及下载算法。本次保留原配置作为学习快照，未创建修正版或替换硬件。

## 已确认边界问题

- 原函数采用 `vol=vol*4096/3.3`，强转 u16 后写入 12 位右对齐数据；3.3 V 对应 4096，超出有效码范围。输入异常值、限幅和取整没有完整处理。
- 原程序固定参考电压 3.3 V，不代表实物参考电压已经测得 3.3 V。
- GPIO_SetBits 操作不应按注释解释为在模拟模式下控制 DAC 高电平。
- 关闭输出缓冲只是原例程选择，不是证明缓冲器存在故障；负载和可用输出范围需查具体器件资料。
- main 中设定 1.65 只表示软件目标，不构成电压实测证据。

## 保留与排除

保留原工程中的 `.c`、`.h`、`.s`、`.uvprojx` 及原 README，包含项目引用的源码与头文件依赖，保留第三方版权和模板署名。

排除 OBJ、`.map`、`.lst`、`.uvoptx`、`.uvguix.*`、JLinkSettings.ini、DebugConfig、历史构建日志以及清理脚本。没有运行原目录中的批处理，也未将个人下载器设置带入上传包。

[SOURCE_SHA256SUMS.txt](SOURCE_SHA256SUMS.txt)与[SOURCE_MANIFEST.json](SOURCE_MANIFEST.json)只记录包内相对路径、文件哈希与大小，不包含本机绝对来源路径。
